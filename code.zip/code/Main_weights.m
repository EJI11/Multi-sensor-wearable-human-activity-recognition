% % WARD 传感器权重数据
sensorWeights = [0.0272, 0.0541, 0.0531, 0.2896, 0.1708, 0.0379, 0.2218, 0.0593, 0.0529, 0.0334];

% 定义具体传感器名称（替换原 S_1 等标签）
sensorLabels = {
    'Left forearm\Acc',   % 对应 S1
    'Left forearm\Gyro',  % 对应 S2
    'Right forearm\Acc',  % 对应 S3
    'Right forearm\Gyro', % 对应 S4
    'Waist\Acc',          % 对应 S5
    'Waist\Gyro',         % 对应 S6
    'Left ankle\Acc',     % 对应 S7
    'Left ankle\Gyro',    % 对应 S8
    'Right ankle\Acc',    % 对应 S9
    'Right ankle\Gyro'    % 对应 S10
};

% sensorWeights = [0.08, 0.51, 0.06, 0.1, 0.06, 0.07, 0.05, 0.07];
% % 8个传感器的完整标签（包含“位置\类型”）
% sensorLabels = {
%     'Chest\Acc',                  % 对应 S1
%     'Left-ankle\Acc',             % 对应 S2
%     'Left-ankle\Gyro',            % 对应 S3
%     'Left-ankle\Magn',            % 对应 S4
%     'Right-lower-arm\Acc',        % 对应 S5
%     'Right-lower-arm\Gyro',       % 对应 S6
%     'Right-lower-arm\Magn',       % 对应 S7
%     'Electrocardiogram signal'    % 对应 S8（无“\类型”分隔，按表格原文）
% };

% % 22个传感器的权重数据
% sensorWeights = [0.0012, 0.003, 0.026, 0.125, 0.012, 0.0569, 0.103, 0.0147, 0.18, 0.18, 0.0578, 0.1896, 0.0055, 0.0225, 0.005, 0.003, 0.0016, 0.005, 0.0019, 0.003, 0.0013, 0.0017];  
% sensorLabels = {
%     'Right knee up\Acc',        % S1
%     'Hip\Acc',                  % S2
%     'Left upper arm up\Acc',    % S3
%     'Right upper arm down\Acc', % S4
%     'Left hand\Acc',            % S5
%     'Back\Acc',                 % S6
%     'Right knee down\Acc',      % S7
%     'Right wrist\Acc',          % S8
%     'Right upper arm up\Acc',   % S9
%     'Left upper arm down\Acc',  % S10
%     'Left wrist\Acc',           % S11
%     'Back\IMU',                 % S12
%     'Right upper arm\IMU',      % S13
%     'Right lower arm\IMU',      % S14
%     'Left upper arm\IMU',       % S15
%     'Left lower arm\IMU',       % S16
%     'Left shoe\IMU',            % S17
%     'Right shoe\IMU',           % S18
%     'Left shoulder\UWB-TAG',    % S19
%     'Right shoulder\UWB-TAG',   % S20
%     'Front shoulder\UWB-TAG',   % S21
%     'Back shoulder\UWB-TAG'     % S22
% };


% 转为 1 行热力图
weightMatrix = sensorWeights(:)';

% 绘制图（调整宽度以适配长标签）
figure('Position', [100, 100, 1200, 300]);  % 适当增加宽度以容纳倾斜标签
imagesc(weightMatrix);

% 自定义蓝色 colormap（浅蓝 → 深蓝）
customBlue = [linspace(0.93, 0.0, 256)', ...   % 红通道：浅→暗
              linspace(0.96, 0.2, 256)', ...   % 绿通道：浅灰蓝→深蓝
              linspace(1.00, 0.6, 256)'];      % 蓝通道：亮蓝→深蓝
colormap(customBlue);
colorbar;

% 设置坐标轴：显示具体名称，旋转标签为45度（斜着显示）
set(gca, ...
    'XTick', 1:length(sensorLabels), ...       % X轴刻度位置
    'XTickLabel', sensorLabels, ...            % X轴刻度标签为具体名称
    'FontSize', 10, ...
    'XTickLabelRotation', 40, ...              % 标签旋转45度，斜着显示
    'YTick', []);                              % 隐藏Y轴刻度
xlabel('Sensors');
title('Sensor Weight Distribution (OSF-EAR Style Blue)');

% 添加黑色分隔线
hold on;
for i = 1:length(sensorWeights)-1
    line([i+0.5, i+0.5], [0.5, 1.5], ...
         'Color', 'black', 'LineStyle', '-', 'LineWidth', 0.8);
end
hold off;