function threshold_weight = threshold_select(weighted)

% 初始化权重数组，示例权重
weights = weighted;

% 设定累积比例阈值
cumulative_threshold = 0.75;

% 将权重从大到小排序
sorted_weights = sort(weights, 'descend');

% 计算总权重
total_weight = sum(sorted_weights);

% 初始化累积和及阈值
cumulative_sum = 0;
threshold_weight = 0;

% 找到累积权重达到设定比例的位置
for i = 1:size(sorted_weights,2)
    cumulative_sum = cumulative_sum + sorted_weights(i);
    if cumulative_sum >= cumulative_threshold * total_weight
        threshold_weight = sorted_weights(i);
        break;
    end
end

% 输出结果
fprintf('设定的阈值为: %.4f\n', threshold_weight);

% 筛选出大于等于阈值的权重
selected_weights = weights(weights >= threshold_weight);

% 输出满足条件的权重
fprintf('满足阈值的权重: ');
disp(selected_weights);

end