%% 某个cv下的保真度计算 需要参数 激活规则 Activated_rules/Activated_rules_soft   样本标签label

% 假设：
% 1. Activated_rules_soft 是1×N的cell数组，每个元素是该样本激活的规则矩阵
% 2. 规则矩阵中：第1列是规则的类别（待预测的标签），第2-16列是规则前提（用于判断规则是否相同）
% 3. 若你的类别列不是第1列，请修改代码中的列索引（如改为end表示最后一列）

% --------------------- 步骤1：收集规则信息（特征+类别+样本索引） ---------------------
ruleFeatures = [];    % 存储所有规则的前提特征（第2-16列，每行一条规则）
ruleClasses = [];     % 存储对应规则的类别（第1列）
sampleIndices = [];   % 存储激活该规则的样本索引（第几个样本）
 label = TestData{1}(:,1);
%  label = label1{4};
% 遍历每个样本（样本索引从1开始）
s=1;
for s = 1:size(Activated_rules,2)
    currRuleIndices=[];
    currRulesMat=[];
    ruleFeatures=[];
    ruleClasses=[];
    sampleIndices=[];
for sampleIdx = 1:size(Activated_rules{s}, 2)
    % 获取当前样本激活的规则矩阵
    currRulesMat = Activated_rules{s}{1, sampleIdx};
    if isempty(currRulesMat)
        continue;  % 无激活规则则跳过
    end
    
    % 提取当前样本中所有规则的：前提特征（2-16列）、类别（1列）
    currFeatures = currRulesMat(:, 2:11);  % 前提特征（判断规则是否相同）
    currClasses = currRulesMat(:, 1);      % 规则的类别标签（需与模型分类对比）
    
    % 记录当前样本的索引（重复记录，与规则数量一致）
    currSampleIndices = repmat(sampleIdx, size(currRulesMat, 1), 1);
    
    % 合并到总列表
    ruleFeatures = [ruleFeatures; currFeatures];
    ruleClasses = [ruleClasses; currClasses];
    sampleIndices = [sampleIndices; currSampleIndices];
end

% 检查是否有数据
if isempty(ruleFeatures)
    error('没有激活的规则数据');
end


% --------------------- 步骤2：去重并统计唯一规则 ---------------------
% 按前提特征（2-16列）去重，得到唯一规则
[uniqueFeatures, ~, uniqueIndices] = unique(ruleFeatures, 'rows');
numUniqueRules = size(uniqueFeatures, 1);  % 唯一规则的数量


% --------------------- 步骤3：整理每条唯一规则的信息 ---------------------
% 初始化结果存储（结构体数组，每个元素对应一条唯一规则）
uniqueRules = struct( ...
    'features', [], ...       % 规则前提（2-16列）
    'class', [], ...          % 规则的类别标签
    'activationCount', 0, ... % 激活样本数
    'sampleIndices', [] ...   % 激活该规则的所有样本索引
);

% 遍历每条唯一规则，填充信息
for i = 1:numUniqueRules
    % 1. 规则前提特征
    uniqueRules(i).features = uniqueFeatures(i, :);
    
    % 2. 规则类别（相同前提的规则应具有相同类别，这里取第一个出现的类别）
    % （若存在相同前提但不同类别的规则，会警告提示）
    currRuleIndices = find(uniqueIndices == i);  % 所有属于该唯一规则的原索引
    currClasses = ruleClasses(currRuleIndices);
    if length(unique(currClasses)) > 1
        warning(['第', num2str(i), '条规则存在相同前提但不同类别，已取第一个类别']);
    end
    uniqueRules(i).class = currClasses(1);  % 取第一个类别
    
    % 3. 激活样本数
    uniqueRules(i).activationCount = length(currRuleIndices);
    
    % 4. 激活该规则的所有样本索引（去重，避免同一样本多次激活同一规则时重复记录）
    uniqueRules(i).sampleIndices = unique(sampleIndices(currRuleIndices));
end


% --------------------- 步骤4：结果展示（转换为表格便于查看） ---------------------
% 提取结构体信息到表格
featuresCell = cell(numUniqueRules, 1);
classes = zeros(numUniqueRules, 1);
counts = zeros(numUniqueRules, 1);
sampleIndicesCell = cell(numUniqueRules, 1);

for i = 1:numUniqueRules
    featuresCell{i} = uniqueRules(i).features;
    classes(i) = uniqueRules(i).class;
    counts(i) = uniqueRules(i).activationCount;
    sampleIndicesCell{i} = uniqueRules(i).sampleIndices;
end

resultTable = table(featuresCell, classes, counts, sampleIndicesCell, ...
    'VariableNames', {'Rule_Features(Col2-16)', 'Rule_Class', 'Activated_Count', 'Sample_Indices'});

% 显示结果
disp('唯一规则统计（含类别和激活样本索引）：');
disp(resultTable);

% 假设：
% 1. 已运行上一步代码，得到 resultTable（包含规则类别、激活样本索引等）
% 2. label 是一个向量，label(k) 表示第k个样本的真实类别（与样本索引对应）
% 3. 若未生成 resultTable，请先运行上一步的规则统计代码

% --------------------- 检查输入有效性 ---------------------
if ~exist('resultTable', 'var')
    error('请先运行规则统计代码生成 resultTable');
end
if ~exist('label', 'var')
    error('未找到样本真实标签变量 label');
end

% 获取规则总数
numRules = height(resultTable);

% 初始化保真度存储
fidelities = zeros(numRules, 1);

% --------------------- 计算每条规则的保真度 ---------------------
for i = 1:numRules
    % 1. 获取当前规则的信息
    ruleClass = resultTable.Rule_Class(i);          % 规则自身的类别
    sampleIndices = resultTable.Sample_Indices{i};  % 激活该规则的样本索引
    totalSamples = resultTable.Activated_Count(i);  % 激活样本总数
    
    % 2. 处理特殊情况（无激活样本）
    if totalSamples == 0
        fidelities(i) = NaN;  % 无样本时保真度无意义
        continue;
    end
    
    % 3. 提取这些样本的真实类别
    % （确保样本索引不超过 label 的长度，避免索引错误）
    validIndices = sampleIndices(sampleIndices <= length(label));
    if isempty(validIndices)
        warning(['第', num2str(i), '条规则的激活样本索引超出 label 范围，保真度设为 0']);
        fidelities(i) = 0;
        continue;
    end
    trueLabels = label(validIndices);  % 真实类别
    
    % 4. 统计真实类别与规则类别一致的数量
    matchCount = sum(trueLabels == ruleClass);
    
    % 5. 计算保真度（匹配数 / 总激活样本数）
    fidelities(i) = matchCount / totalSamples;
end


% --------------------- 整合结果到表格 ---------------------
% 在原结果表格中添加保真度列
resultTable.Fidelity = fidelities;

% 按保真度从高到低排序（可选，方便查看）
resultTable = sortrows(resultTable, 'Fidelity', 'descend');

% 显示最终结果
disp('每条规则的保真度统计（按保真度降序排列）：');
disp(resultTable);

av_f=resultTable(:,5);
Av_f(s)=sum(av_f{:,1}) / size(av_f,1);
Final_av=sum(Av_f,2)/size(Av_f,2);
end