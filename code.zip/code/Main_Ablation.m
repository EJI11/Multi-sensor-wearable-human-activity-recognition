%消融实验

clear
clc
close all


%MC 
Mc=1;

Data1 = {'Opportunity'};%数据加载  

%% ********** 特征提取+特征选择*******************
%特征提取**********************************
for k = 1:size(Data1,2)
     load(Data1{k});
    Dataset = eval(Data1{k});
    Num = size(Dataset,2);
    Hz = 50;
    length = 2.56*ceil(Hz/1);
    cover_per = ceil(length /2);%覆盖率
    Data = [];
    attribute = [];
    tem_data = [];
   
    for j1 = 1:Num
        data_i = Dataset{j1};%第i个受试者数据，矩阵
        formissdata = Delete_outlier(data_i); %异常值检测
        data_i = Delete_Miss(formissdata); %缺失值检测
        n = size(data_i,2);%维度
        D = data_i(:,1:n);%取出特征
       m1 = size(D,1);%样本数
        for i = 1:cover_per:m1
            if i+length <= m1 %i = m1时，就不再提取窗口
                column_label = unique(D(i:i+length-1,n)); %取出标签数据
                  if  size(column_label,1) == 1 && column_label~= 0 %检查窗口内是否只包含一个标签，并且这个标签不为零。
                      column = D(i:i+length-1,:);%取出窗口的所有列,该窗口包含原始数据的所有列（计算时对窗口内的数据逐列计算）
                        for j = 1:n-1 %遍历窗口数据
                         column_i = column(:,j);%对窗口的数据一列一列的计算特征，不算最后一列标签列
                         [x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11] = For_attribute(column_i);
                         attribute_collection = [x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11];
                         tem_data = [tem_data,attribute_collection];%一个窗口中每一列的20个特征，横向排列。（若窗口有3列，则每列20个特征（20维），就是60维）。注意：1-20列就是窗口的第一列特征，20-40就是窗口第二列特征，以此类推
                        end
                        attribute = [column_label,tem_data];
                         tem_data = [];
                 end
           end
           Data = [Data;attribute];
           attribute = [];
        end
    end


%特征选择**************************************

   set = Data;
   set1=Data(:,2:end);
   labels = Data(:,1);

   feather=Data(:,2:size(Data,2));

   [idx,scores] = fscmrmr(feather,labels);
    S = idx;
%     S = S+1;
   Label = Data(:,1);%类别标签
   Feature = set1(:,S(:,10:19));%特征矩阵
   Data = [Label,Feature];%组成数据矩阵

   DataSet = Data;


%    DataSet = eval(Data1{k});
                                                                        %% ***************交叉验证5CV+信源提取*********************
 for m = 1:Mc
   %交叉验证*************************************** 
        B=5;
        SetNum = size(DataSet,1);
        RandIndex = randperm(SetNum);
        for i = 1:B % 该循环是产生5CV的过程
            TestIndex{i} = [];
            TrainingIndex{i} = [];
            for ind = 1:SetNum
                if ind >= ((i-1) * floor(SetNum/B)+1) && ind <= (i * floor(SetNum/B))
                    TestIndex{i} = [TestIndex{i} RandIndex(ind)];
                else
                    TrainingIndex{i} = [TrainingIndex{i} RandIndex(ind)];
                end
            end
            TrainingData{i} = DataSet(TrainingIndex{i},:);
            TestData{i} = DataSet(TestIndex{i},:);
        end
        TrainingDataCV{m} = TrainingData;
        TestDataCV{m} = TestData;
%  save Opportunity_cv TrainingData TestData
%信源提取**********************************
% [S1,S2,S3,S4,S5,S6,S7,S8] = mhealth_S(TrainingData,TestData,S,B);
[S1,S2,S3,S4,S5,S6,S7,S8,S9,S10,S11,S12,S13,S14,S15,S16,S17,S18,S19,S20,S21,S22] = Opportunity_S(TrainingData,TestData,S,B);
% [S1,S2,S3,S4,S5,S6,S7,S8,S9,S10] = WARD_S(TrainingData,TestData,S,B);

%% **********************获取规则库(训练集识别)*********************
Train_time=tic;
% Data2={'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10'}; 
Data2={'S1','S2','S3','S4','S5','S6','S7','S8'};     
% Data2={'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10','S11','S12','S13','S14','S15','S16','S17','S18','S19','S20','S21','S22'};    
for h = 1: size(Data2,2) 
  S_Data= eval(Data2{h}); 
  TrainingData = S_Data{1};
  TestData = S_Data{2};
  DataSet1 = TestData{1};
  Label = DataSet1(:,1);
  M=size(unique(Label),1); %目标类别数目

  % CV数据
  TK = 5;
  % 
  Train_normalization_matrix = zeros(M,M);
  %5个cv下频繁项集挖掘
  B=1;
  for cv = 1:B
    single_trainF_t_cv = tic;
    %可能会影响性能的几个阈值设置
    min_sup=0.01;  %最小支持度阈值
    min_conf=0.8; %最小置信度阈值
    Fre_limits=6000; %给学习到的最大频繁项集数目设定一个上限
    N_max = 1000; %规则约简使用的样本数目上限
    beforereduct_TrainData = TrainingData{cv};
    beforereduct_TestingData = TestData{cv};
    Label_fine{cv} = [beforereduct_TrainData(:,1);beforereduct_TestingData(:,1)];
    Label_category{cv} = (unique(Label_fine{cv}))';
    Attribute_data{cv} = [beforereduct_TrainData(:,2:end);beforereduct_TestingData(:,2:end)];
   n = size(Attribute_data{cv},2)+1;
   P = n-1;
   m0 = size(beforereduct_TrainData,1);%训练集样本数
   m1 = size(beforereduct_TestingData,1);%测试集样本数
   fine_data = [Label_fine{cv},Attribute_data{cv}];
   fine_train_data = beforereduct_TrainData;
   fine_test_data = beforereduct_TestingData;
   fine_train_label_cv = fine_train_data(:,1);
   fine_train_label{cv} = fine_train_label_cv;
   fine_test_label{cv}  = fine_test_data(:,1);
   Fine_Label{cv} = fine_test_data;
%     load(Data_CV{cv})
    %离散化+频繁项集+规则选择+分类器选择_单框架
    [Fine_F,Fine_Sup,Fine_Sum,Fine_Mu,Fine_Disc_K,Fine_Num_disc,Fine_Num_disc_PointSets,Fine_Disc,attribute_min,attribute_max] = F_Gen(fine_data,Label_fine{cv},P,m0,n,min_sup,Fre_limits); 
    F{cv} = Fine_F;
    Sup{cv} = Fine_Sup;
    Sum{cv} = Fine_Sum;
    Mu{cv} = Fine_Mu;
    Num_disc{cv} = Fine_Num_disc;
    Disc_K{cv} = Fine_Disc_K;
    Disc{cv} = Fine_Disc;
    PointSets{cv} = Fine_Num_disc_PointSets;
    attribute_min1{cv} = attribute_min;
    attribute_max1{cv} = attribute_max;
    single_trainF_t_cv = toc(single_trainF_t_cv);
    single_trainF_t{cv} = single_trainF_t_cv;
  end
%5个cv下规则挖掘
  for cv = 1:B
    Fine_Sup = Sup{cv};
    Fine_Sum = Sum{cv};
    Fine_Mu = Mu{cv};
    Fine_F =F{cv};
   fine_train_label_cv = fine_train_label{cv};
    single_trainF_t_cv = single_trainF_t{cv};
    
    single_trainC_t_cv = tic;
    Fine_Training_Mu = Fine_Mu(:,1:m0);
    Train_Mu{cv}=Fine_Training_Mu;%用于保存信源变量
    Fine_Testing_Mu{cv} = Fine_Mu(:,m0+1:m0+m1);%用于保存信源变量
    [Fine_R,Fine_Training_MatchingSet] = CAR_Generate(Fine_F,Fine_Sup,Fine_Sum,P,Fine_Training_Mu,fine_train_label_cv,n,min_conf,M);
    R{cv} = Fine_R;
    Training_MatchingSet{cv} = Fine_Training_MatchingSet;    
   [Fine_C,Fine_Default,Fine_Classifier_candi_default,Fine_True_value,Fine_Classifier_TrueUsed,Fine_Classfication_Number] = classifier_selecting_building(Fine_Training_MatchingSet,Fine_R,Fine_Training_Mu,m0,M,TK,P,n);%Fine
    Fine_max_value = max(Fine_True_value);%获得正确率最大值
    Fine_location = find(Fine_True_value == Fine_max_value);%获得正确率最大值的位置
    Fine_final_C_cv{1,1}{1,1} = Fine_C(1:Fine_location(1),:);%找到规则数最少且正确率最大的分类器
    Fine_final_C_cv{1,1}{2,1} = Fine_Default(Fine_location(1));%对应的默认类
    Fine_final_C{cv} = Fine_final_C_cv;%每个cv下的分类器规则和对应得默认类（最终）
    Default{cv} =  Fine_final_C_cv{1}{2,1};%单独存每个cv下的默认类
    classifier_rules{cv} = Fine_final_C_cv{1}{1};%单独存每个cv下的分类器规则
%    %训练集识别
    for i2 = 1:m0
       [Train_classification_result(i2,1),single_Traintrue(i2,1),Train_used_Rule_number(i2,1)] = Mass_matrix(fine_train_label_cv(i2),Fine_final_C_cv{1,1}{1,1},M,Fine_final_C_cv{1,1}{2,1},TK, Fine_Training_Mu{1,i2},P); %%选取规则融合后的最大值
    end
   [train_class_matrix,train_normalization_matrix] =  matrix_analyze(Train_classification_result,fine_train_label_cv,M,m0); %混淆矩阵
   Train_normalization_matrix = Train_normalization_matrix + train_normalization_matrix;
   Train_matrix{cv}{1}= train_class_matrix;
   Train_matrix{cv}{2}= train_normalization_matrix;    
   single_trainC_t_cv = toc(single_trainC_t_cv);
   
   single_traintC_t{cv} = single_trainC_t_cv;
   single_train_t_cv = single_trainC_t_cv+single_trainF_t_cv;
   single_train_t{cv} = single_train_t_cv;

  end  
%% 混淆矩阵 
    TrainAver_normalization_matrix = Train_normalization_matrix/B;  
%%存储每个信源的结果 
Single_train_t{h}=single_train_t;
Disc_all{h} = Disc;
Final_C{h} = Fine_final_C;
Rule{h} = R;
Attribute_min{h}=attribute_min1;
Attribute_max{h}=attribute_max1;
Classifier_rules{h}=classifier_rules;
Classifier_default{h}=Default;
Confusion_matrix{h}=TrainAver_normalization_matrix;
Training_Mu{h}=Train_Mu;
Testing_Mu{h} = Fine_Testing_Mu;
Fine_test_label{h} = fine_test_label;
P_all{h} = P;
Num_disc_all{h}=Num_disc;
Disc_K_all{h}=Disc_K;
PointSets_all{h}=PointSets;
 end

end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Train_time=toc;
   %% 利用遗传算法生成各信源的权重
tic;
weighs=[];
best_fitness=[];
for u = 1:10                                                                           
%    [weighs(u,:),best_fitness{u}] = test_ga(Confusion_matrix);
   [weighs(u,:),best_fitness{u}] = test_ga_Opportunity(Confusion_matrix);
%    [weighs(u,:),best_fitness{u},elite{u},case_population,case_initial] = test_ga_mhealth(Confusion_matrix);
end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%画迭代图
best_fitness=best_fitness{1}(:,1:156);
plot(best_fitness, 'LineWidth', 1);  % 绘制主曲线
xlabel('Iteration');                 % x轴标签
ylabel('Fitness Value');             % y轴标签
title('Best Fitness Trend');         % 图表标题
grid on; 

% 先获取当前坐标轴范围，避免直接调用ylim(1)/xlim(1)的兼容问题
x_range = xlim;  % x轴范围：[xmin, xmax]
y_range = ylim;  % y轴范围：[ymin, ymax]

% 调整坐标轴范围（稍微扩展，让虚线延长）
new_xlim = [x_range(1)-5, x_range(2)+5];  % 左右各扩展5
new_ylim = [y_range(1)-0.1, y_range(2)+0.1];  % 上下各扩展0.1（根据数据调整）
xlim(new_xlim);
ylim(new_ylim);

% 添加垂直虚线（x=156）和水平虚线（y=2.18）
xline(156, '--', 'Color', [0.5,0.5,0.5], 'LineWidth', 1);
yline(2.18, '--', 'Color', [0.5,0.5,0.5], 'LineWidth', 1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 找到每行的最小值
min_values = min(weighs, [], 2);

% 计算每列出现最小值的次数
count_min_values = zeros(1, size(weighs, 2));

for i = 1:size(weighs, 2)
    count_min_values(i) = sum(weighs(:, i) == min_values);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%方法1：阈值筛选
for y = 1:h
    sum_w(y) = sum(weighs(:,y));
    sum_w(y) = sum_w(y)/u;
end


Pi = threshold_select(sum_w);
index = find(sum_w < Pi);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%保存原始变量，便于调试
Fine_test_label_q=Fine_test_label;
Classifier_rules_q=Classifier_rules;
Classifier_default_q=Classifier_default;
Testing_Mu_q=Testing_Mu;
Disc_all_q=Disc_all;
Final_C_q=Final_C;


%消融实验-传感器选择部分，调试时不执行去除信源部分的代码（SS）
Fine_test_label=Fine_test_label_q;
Classifier_rules=Classifier_rules_q;
Classifier_default=Classifier_default_q;
Testing_Mu=Testing_Mu_q;
Disc_all=Disc_all_q;
Final_C=Final_C_q;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%去除信源
Fine_test_label(index)=[];
Classifier_rules(index)=[];
Classifier_default(index)=[];
Testing_Mu(index)=[];
% sum_wr=ones(1,22);%消融实验-折扣部分（WS）
sum_wr=sum_w; %存所有信源的权重
sum_wr(index)=[];%被选择的信源权重
Disc_all(:, index) = [];
Final_C(:, index) = [];
Rule(:, index)=[];%消融实验-规则选择部分(WS)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%测试阶段
tic

% fusion_mass={};
% Activated_rules={};
% Final_mass={};
% struct_mass={};
% Test_normalization_matrix = zeros(M,M);
% 所有规则库对测试样本分类
for t = 1:size(Fine_test_label,2)
 for c = 1:B
    for i3 = 1:m1
        [Testclassification_result{t}{c}(i3,1),fusion_mass{t}{c}(i3,:),single_Testtrue{t}{c}(i3,1),Test_used_Rule_number{t}{c}(i3,1),Activated_rules{t}{c}{i3}] = Mass_matrix1(Fine_test_label{t}{c}(i3),Rule{t}{c},M,Classifier_default{t}(c),TK, Testing_Mu{t}{c}{i3},P_all{t}); %%选取规则融合后的最大值      
        Correct{t}{c} = sum(single_Testtrue{t}{c} == 1)/size(single_Testtrue{t}{c},1);
    end
%       [test_class_matrix,test_normalization_matrix] =  matrix_analyze(Testclassification_result{t}{c},Fine_test_label{t}{c},M,m1); %混淆矩阵
%    Test_normalization_matrix = Test_normalization_matrix + test_normalization_matrix;
 end
%  TestAver_normalization_matrix = Test_normalization_matrix/B;
%  Test_matrix{t} = TestAver_normalization_matrix;
%  Test_normalization_matrix = zeros(M,M);
end
%% 每个信源规则库之间的融合(最终mass)
for j = 1:B
    for p = 1:size(TestData{1},1)
           Final_mass{j}(p,:) = Mass_Combination(fusion_mass,sum_wr,M,j,p); %mass融合，当发生完全冲突即（k=1）时，给Ω赋值为1.
    end                           
%% 识别结果转pignistic
 %mass转换为struct
    Label_category = unique(TestData{1}(:,1));
    for i = 1:size(TestData{1},1)
        struct_mass{i} = mass_matrix2struct(Final_mass{j}(i,:),M,Label_category); 
    end
   

      Pignistic_mass= struct_mass;%多框架
      for i = 1:size(TestData{1},1)
          Sample_Plignistic(i,:) = Gen_Pignistic_rule_fusion(Pignistic_mass{i},M);
          FL1 = find(Sample_Plignistic(i,:) >= 0.99999999);
          FL0 = find(Sample_Plignistic(i,:) <= 0.00000001);%删除奇异值
          Sample_Plignistic(i,FL1) = 1;
          Sample_Plignistic(i,FL0) = 0;
      end
    [Multi_True,Multi_classification_result] = test_correct_belief(Sample_Plignistic,Fine_test_label{1}{j},M,Default{j});
%        [multi_class_matrix,multi_normalization_matrix] =  matrix_analyze(Multi_classification_result,fine_test_label{j},M,m1); %混淆矩阵
%          Multi_class_matrix{j}=multi_class_matrix;
%        Multi_normalization_matrix{j}=multi_normalization_matrix;

%        %平均混淆矩阵
%        matrix=zeros(size(multi_normalization_matrix,2));
%        for i = 1:5
%            matrix=matrix+Multi_normalization_matrix{i};
%        end
%        Matrix=matrix/5;
        
        Multi_true = sum(Multi_True(:));
        M_t{j} = Multi_true;
        M_T{j} = Multi_True;
        multi_correct = Multi_true/m1;
        Multi_correct{j} = multi_correct;
        Final_Sample_Plignistic{j}=Sample_Plignistic;
end
Time_test=toc;


    